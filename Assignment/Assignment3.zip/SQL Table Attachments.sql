CREATE TABLE [Attachments](
[AID] int not null PRIMARY KEY,
[File] image not null,
[File Name] nvarchar(MAX) not null,
[MID] int not null
);