CREATE TABLE [USER](
[UserID] int not null PRIMARY KEY,
[Password] ntext not null,
[FirstName] nvarchar(MAX) not null,
[LastName] nvarchar(MAX) not null
);